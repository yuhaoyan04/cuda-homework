#include "student_sdf.cuh"

// STATIC REQUIRED (students): Implement signed-distance field generation in CUDA.
// The dynamic-update bonus is optional and is not implemented by this starter.
// You may use multiple kernels, temporary GPU buffers, custom spatial structures,
// and CUDA library primitives. But all required work must be measured by the
// teacher's CUDA event pair around this function. Initialize EVERY output element.
// The starter intentionally does NOT output fake/zero distances.

cudaError_t student_sdf_cuda(
    const float* /*d_vertices*/, int /*num_vertices*/,
    const std::uint32_t* /*d_triangles*/, int /*num_triangles*/,
    StudentGrid /*grid*/, float* /*d_sdf*/,
    cudaStream_t /*stream*/) {
    return cudaErrorNotSupported;
}
